
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Clients from "./pages/Clients";
import Products from "./pages/Products";
import Orders from "./pages/Orders";
import MagicOrder from "./pages/MagicOrder";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";
import { TooltipProvider } from "@/components/ui/tooltip";
import Messages from "./pages/Messages";
import { SidebarProvider } from "@/components/ui/sidebar";
import ProductDetails from "./pages/ProductDetails";
import { ThemeProvider } from "@/components/theme-provider";
import { Toaster } from "@/components/ui/toaster";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { GOOGLE_GEMINI_MODELS } from "@/lib/api-config";
import { setGeminiModel } from "@/services/geminiService";
import { GlobalProgressBar } from "@/components/GlobalProgressBar";
import { APP_VERSION } from "@/lib/app-config";

const App = () => {
  const { toast } = useToast();
  const [isAnalyzingGlobally, setIsAnalyzingGlobally] = useState(false);
  
  // Configuramos la API de Gemini globalmente al inicio
  useEffect(() => {
    // Establecemos el modelo Gemini Flash 2 como predeterminado para toda la aplicación
    setGeminiModel(GOOGLE_GEMINI_MODELS.GEMINI_FLASH_2);
    
    console.log(`API configurada para toda la aplicación: Google Gemini 2.0 Flash (v${APP_VERSION})`);
    
    // Chequear y limpiar datos de análisis antiguos al iniciar
    const cleanupOldData = () => {
      try {
        const backgroundAnalysis = localStorage.getItem('magicOrder_backgroundAnalysis');
        if (backgroundAnalysis) {
          const parsedAnalysis = JSON.parse(backgroundAnalysis);
          const timestamp = new Date(parsedAnalysis.timestamp);
          const now = new Date();
          const hoursDiff = (now.getTime() - timestamp.getTime()) / (1000 * 60 * 60);
          
          // Si el análisis tiene más de 12 horas, lo eliminamos
          if (hoursDiff > 12) {
            console.log("Eliminando análisis antiguo de más de 12 horas");
            localStorage.removeItem('magicOrder_backgroundAnalysis');
            sessionStorage.removeItem('magicOrder_isAnalyzing');
            sessionStorage.removeItem('magicOrder_progress');
            sessionStorage.removeItem('magicOrder_stage');
          }
        }
      } catch (error) {
        console.error("Error al limpiar datos antiguos:", error);
      }
    };
    
    cleanupOldData();
  }, []);
  
  // Escuchar cambios en el estado del análisis en cualquier parte de la aplicación
  useEffect(() => {
    // Primero, intentamos restaurar el estado desde localStorage para persistencia entre sesiones
    const restoreAnalysisState = () => {
      const backgroundAnalysis = localStorage.getItem('magicOrder_backgroundAnalysis');
      
      if (backgroundAnalysis) {
        try {
          const parsedAnalysis = JSON.parse(backgroundAnalysis);
          setIsAnalyzingGlobally(parsedAnalysis.status === 'analyzing');
          
          // Notificamos del estado recuperado
          const event = new CustomEvent('analysisStateChange', {
            detail: { 
              isAnalyzing: parsedAnalysis.status === 'analyzing',
              progress: parsedAnalysis.progress || 5,
              stage: parsedAnalysis.stage || "Análisis en curso...",
              tokenId: parsedAnalysis.tokenId || null,
              timestamp: parsedAnalysis.timestamp || new Date().toISOString()
            }
          });
          window.dispatchEvent(event);
          
          console.log("Estado de análisis restaurado desde localStorage:", {
            isAnalyzing: parsedAnalysis.status === 'analyzing',
            progress: parsedAnalysis.progress,
            stage: parsedAnalysis.stage,
          });
          
          return true;
        } catch (error) {
          console.error("Error al parsear análisis en segundo plano:", error);
        }
      }
      
      // Si no hay análisis en localStorage, intentamos con sessionStorage
      const savedIsAnalyzing = sessionStorage.getItem('magicOrder_isAnalyzing');
      
      if (savedIsAnalyzing === 'true') {
        const savedProgress = sessionStorage.getItem('magicOrder_progress');
        const savedStage = sessionStorage.getItem('magicOrder_stage');
        const progress = savedProgress ? parseFloat(savedProgress) : 5;
        
        setIsAnalyzingGlobally(true);
        
        // Notificamos del estado recuperado
        const event = new CustomEvent('analysisStateChange', {
          detail: { 
            isAnalyzing: true,
            progress: progress,
            stage: savedStage || "Análisis en curso..."
          }
        });
        window.dispatchEvent(event);
        
        console.log("Estado de análisis restaurado desde sessionStorage:", {
          isAnalyzing: true,
          progress: progress,
          stage: savedStage
        });
        
        return true;
      }
      
      return false;
    };
    
    // Ejecutamos la restauración al iniciar
    const wasRestored = restoreAnalysisState();
    
    // Función para manejar el cambio de estado del análisis
    const handleAnalysisStateChange = (event: CustomEvent) => {
      const { isAnalyzing, progress, stage, ordersCount, tokenId, isComplete, timestamp } = event.detail;
      
      console.log("App: Evento de análisis recibido", { 
        isAnalyzing, 
        progress, 
        stage,
        ordersCount,
        isComplete,
        timestamp: timestamp || new Date().toISOString()
      });
      
      // Actualizamos el estado global
      setIsAnalyzingGlobally(isAnalyzing);
      
      // Guardamos el estado actual en sessionStorage para mantenerlo entre navegaciones
      if (isAnalyzing) {
        sessionStorage.setItem('magicOrder_isAnalyzing', 'true');
        if (progress) sessionStorage.setItem('magicOrder_progress', String(progress));
        if (stage) sessionStorage.setItem('magicOrder_stage', stage);
        sessionStorage.setItem('magicOrder_timestamp', timestamp || new Date().toISOString());
        
        // Si hay un tokenId, también actualizamos el estado en localStorage
        if (tokenId) {
          localStorage.setItem('magicOrder_backgroundAnalysis', JSON.stringify({
            tokenId,
            status: 'analyzing',
            stage: stage || "Análisis en curso...",
            progress: progress || 5,
            timestamp: timestamp || new Date().toISOString()
          }));
        }
      } else {
        // Si el análisis ha terminado, limpiamos los datos de sessionStorage
        sessionStorage.removeItem('magicOrder_isAnalyzing');
        sessionStorage.removeItem('magicOrder_progress');
        sessionStorage.removeItem('magicOrder_stage');
        
        // Si hay un tokenId, actualizamos el estado en localStorage
        if (tokenId) {
          if (isComplete) {
            localStorage.setItem('magicOrder_backgroundAnalysis', JSON.stringify({
              tokenId,
              status: 'completed',
              progress: 100,
              timestamp: timestamp || new Date().toISOString()
            }));
          } else {
            // Si no está completo, eliminamos el análisis
            localStorage.removeItem('magicOrder_backgroundAnalysis');
          }
        } else {
          // Si no hay token, simplemente eliminamos
          localStorage.removeItem('magicOrder_backgroundAnalysis');
        }
      }
      
      // Cuando el análisis termina y hay órdenes detectadas
      if (!isAnalyzing && typeof ordersCount === 'number' && ordersCount > 0) {
        // Mostrar un toast para notificar que se han detectado órdenes
        toast({
          title: "Análisis completado",
          description: `Se ${ordersCount === 1 ? 'ha' : 'han'} detectado ${ordersCount} pedido${ordersCount === 1 ? '' : 's'}`,
          variant: "success",
        });
      }
    };
    
    // Añadir el listener para el evento de análisis
    window.addEventListener('analysisStateChange', handleAnalysisStateChange as EventListener);
    
    // Añadir listener para visibilidad de página
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        console.log("Pestaña visible, verificando estado de análisis");
        restoreAnalysisState();
      }
    };
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    return () => {
      window.removeEventListener('analysisStateChange', handleAnalysisStateChange as EventListener);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [toast]);
  
  return (
    <ThemeProvider defaultTheme="light" storageKey="app-theme">
      <TooltipProvider>
        <SidebarProvider>
          <BrowserRouter>
            <GlobalProgressBar />
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/clients" element={<Clients />} />
              <Route path="/products" element={<Products />} />
              <Route path="/orders" element={<Orders />} />
              <Route path="/magic-order" element={<MagicOrder />} />
              <Route path="/messages" element={<Messages />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/product-details/:productId" element={<ProductDetails />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
          <Toaster />
        </SidebarProvider>
      </TooltipProvider>
    </ThemeProvider>
  );
};

export default App;
