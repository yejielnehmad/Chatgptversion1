
import { logError } from './debug-utils';

/**
 * Analiza de forma segura una cadena JSON, intentando reparar errores comunes
 */
export const safeJsonParse = (jsonString: string | null): any => {
  if (!jsonString) return null;
  
  try {
    return JSON.parse(jsonString);
  } catch (error) {
    logError("JSONUtils", "Error al parsear JSON:", error);
    
    // Intento de corrección básica: comillas duplicadas
    try {
      const fixedJson = jsonString.replace(/([^\\])""([^\\])/g, '$1\\"$2');
      return JSON.parse(fixedJson);
    } catch (e) {
      // Devolver la cadena original si falla
      return jsonString;
    }
  }
};

/**
 * Convierte de forma segura un objeto a una cadena JSON
 */
export const safeJsonStringify = (obj: any, spaces: number = 0): string => {
  if (!obj) return "";
  
  try {
    return JSON.stringify(obj, null, spaces);
  } catch (error) {
    logError("JSONUtils", "Error al convertir a JSON:", error);
    return String(obj);
  }
};
