
// Configuración de API keys
export const GOOGLE_API_KEY: string = "AIzaSyCLJUKv3dD-5IY5Y-bAFyTJ5v-kQTLe8K8"; // Clave API de Google Gemini

// Configuración de endpoints
export const GOOGLE_GEMINI_ENDPOINT: string = "https://generativelanguage.googleapis.com/v1beta/models";

// Modelos de Google Gemini disponibles
export const GOOGLE_GEMINI_MODELS = {
  GEMINI_FLASH_2: "gemini-2.0-flash"
};

// Configuración de tokens
export const GEMINI_MAX_INPUT_TOKENS: number = 32000;
export const GEMINI_MAX_OUTPUT_TOKENS: number = 8192;

// Versión de la API
export const API_CONFIG_VERSION: string = "1.0.3";

// Fecha de la última actualización de la API
export const API_CONFIG_UPDATED: string = "2025-04-16";
