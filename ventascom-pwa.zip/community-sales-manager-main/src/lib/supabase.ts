
import { supabase } from "@/integrations/supabase/client";

// Evitamos el uso de tablas con políticas RLS restrictivas
// cuando no se ha iniciado sesión
const analyzeWithoutDB = (message: string) => {
  // Esta función simulará el análisis sin usar las tablas de Supabase
  // que tienen políticas RLS restrictivas
  
  // Devolvemos un objeto estándar para ser compatible con el flujo del análisis
  return {
    result: [],
    phase1Response: "Análisis local - sin usar base de datos",
    phase2Response: JSON.stringify({ message: "Análisis local sin DB" }),
    phase3Response: JSON.stringify({ status: "OK" })
  };
};

// Función para recuperar un análisis por su token
const getAnalysisByToken = async (tokenId: string) => {
  try {
    // Primero intentamos obtener el estado del análisis
    const { data: statusData, error: statusError } = await supabase
      .from('analysis_status')
      .select('*')
      .eq('token_id', tokenId)
      .single();
    
    if (statusError) {
      console.error("Error al obtener estado del análisis:", statusError);
      return null;
    }
    
    if (!statusData) {
      return null;
    }
    
    // Si hay un magic_order_id, obtenemos los resultados del análisis
    if (statusData.magic_order_id) {
      const { data: orderData, error: orderError } = await supabase
        .from('magic_orders')
        .select('*')
        .eq('id', statusData.magic_order_id)
        .single();
      
      if (orderError) {
        console.error("Error al obtener resultado del análisis:", orderError);
        return statusData;
      }
      
      if (orderData) {
        return {
          ...statusData,
          result: orderData.result,
          phase1_response: orderData.phase1_response,
          phase2_response: orderData.phase2_response,
          phase3_response: orderData.phase3_response,
          analysis_time: orderData.analysis_time
        };
      }
    }
    
    return statusData;
  } catch (error) {
    console.error("Error al recuperar análisis por token:", error);
    return null;
  }
};

// Función para manejar análisis en segundo plano
const handleBackgroundAnalysis = async (tokenId: string) => {
  // Función para suscribirse a cambios en el estado del análisis
  const subscribeToAnalysis = () => {
    const channel = supabase
      .channel(`analysis-status-${tokenId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'analysis_status',
          filter: `token_id=eq.${tokenId}`,
        },
        (payload) => {
          const { new: newData } = payload;
          console.log(`Actualización en segundo plano del análisis: ${newData.status}, progreso: ${newData.progress}%`);
          
          // Disparamos un evento para actualizar la UI aunque estemos en otra pestaña
          const event = new CustomEvent('analysisStateChange', {
            detail: { 
              eventType: newData.status === 'completed' ? 'analysis-done' : 'analysis-progress',
              isAnalyzing: newData.status === 'analyzing',
              stage: newData.stage || "Análisis en curso...",
              progress: newData.progress,
              status: newData.status,
              tokenId: tokenId,
              isComplete: newData.status === 'completed'
            }
          });
          window.dispatchEvent(event);
          
          // También guardamos en localStorage para que persista si la app se cierra
          if (newData.status === 'analyzing') {
            localStorage.setItem('magicOrder_backgroundAnalysis', JSON.stringify({
              tokenId,
              status: newData.status,
              stage: newData.stage,
              progress: newData.progress,
              timestamp: new Date().toISOString()
            }));
          } else if (newData.status === 'completed' || newData.status === 'error') {
            // Si el análisis termina, mantenemos el tokenId pero actualizamos el estado
            localStorage.setItem('magicOrder_backgroundAnalysis', JSON.stringify({
              tokenId,
              status: newData.status,
              progress: newData.status === 'completed' ? 100 : newData.progress,
              stage: newData.status === 'completed' ? "Análisis completado" : "Error en el análisis",
              timestamp: new Date().toISOString()
            }));
          }
        }
      )
      .subscribe();
    
    return channel;
  };
  
  const channel = subscribeToAnalysis();
  
  // Guardamos el tokenId en sessionStorage para poder recuperarlo si el usuario navega a otra página
  sessionStorage.setItem('aiTokenId', tokenId);
  sessionStorage.setItem('aiStatus', 'analyzing');
  sessionStorage.setItem('aiMessage', 'IA');
  sessionStorage.setItem('aiDetailedInfo', 'Análisis en segundo plano');
  
  // También guardamos en localStorage para que persista si la app se cierra
  localStorage.setItem('magicOrder_backgroundAnalysis', JSON.stringify({
    tokenId,
    status: 'analyzing',
    stage: 'Análisis en curso...',
    progress: 5,
    timestamp: new Date().toISOString()
  }));
  
  return channel;
};

export { 
  supabase,
  analyzeWithoutDB,
  handleBackgroundAnalysis,
  getAnalysisByToken
};
