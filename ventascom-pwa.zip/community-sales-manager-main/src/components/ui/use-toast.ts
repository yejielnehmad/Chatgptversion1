
// Re-exportamos desde hooks/use-toast
export { useToast, toast } from "@/hooks/use-toast";
