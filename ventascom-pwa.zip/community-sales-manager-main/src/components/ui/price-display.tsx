
import { formatPrice } from "@/lib/format";
import { logError } from "@/lib/debug-utils";
import { useMemo } from "react";

interface PriceDisplayProps {
  value: number | string;
  className?: string;
  /**
   * Si es true, no mostrará el prefijo "$"
   */
  noPrefix?: boolean;
}

/**
 * Componente para mostrar precios formateados con puntos como separadores de miles
 * v1.0.14
 */
export function PriceDisplay({ value, className = "", noPrefix = false }: PriceDisplayProps) {
  const formattedPrice = useMemo(() => {
    try {
      // Validar que valor sea un número válido
      const numValue = typeof value === 'string' ? parseFloat(value) : value;
      
      if (isNaN(numValue)) {
        logError('PriceDisplay', `Valor no numérico: ${value}`);
        return { isError: true, text: noPrefix ? 'Error' : '$Error' };
      }
      
      const formatted = formatPrice(value);
      return { 
        isError: false, 
        text: noPrefix ? formatted.replace('$', '') : formatted 
      };
    } catch (error) {
      logError('PriceDisplay', error, { value });
      return { 
        isError: true, 
        text: noPrefix ? '0' : '$0' 
      };
    }
  }, [value, noPrefix]);
  
  return (
    <span className={`${className} ${formattedPrice.isError ? 'text-red-500' : ''}`}>
      {formattedPrice.text}
    </span>
  );
}
