
import { useState, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface NumberInputProps extends Omit<React.ComponentProps<typeof Input>, 'onChange' | 'value' | 'type'> {
  value: number | null;
  onChange: (value: number | null) => void;
  min?: number;
  max?: number;
  step?: number;
  allowEmpty?: boolean;
  onBlurValidate?: boolean;
}

/**
 * Input optimizado para números con mejor experiencia de usuario
 * Versión 1.0.1
 */
export function NumberInput({ 
  value, 
  onChange, 
  className, 
  min, 
  max, 
  step = 1,
  allowEmpty = false,
  onBlurValidate = true,
  ...props 
}: NumberInputProps) {
  // Usar una cadena para el estado interno para manejar mejor el estado vacío
  const [displayValue, setDisplayValue] = useState<string>(value !== null ? value.toString() : '');
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Actualizar el valor mostrado cuando cambia el valor externo
  useEffect(() => {
    if (value !== null) {
      setDisplayValue(value.toString());
    } else if (allowEmpty) {
      setDisplayValue('');
    } else {
      setDisplayValue('0');
    }
  }, [value, allowEmpty]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;
    
    // Permitir valor vacío si está configurado
    if (inputValue === '') {
      setDisplayValue('');
      if (allowEmpty) {
        onChange(null);
      }
      setError(null);
      return;
    }
    
    // Validar que sea un número
    if (!/^-?\d*\.?\d*$/.test(inputValue)) {
      setError("Solo se permiten números");
      return;
    }
    
    setDisplayValue(inputValue);
    setError(null);
    
    const numValue = parseFloat(inputValue);
    
    // Solo actualizar el valor si es un número válido
    if (!isNaN(numValue)) {
      // Aplicar restricciones min/max en tiempo real
      let validatedValue = numValue;
      
      if (min !== undefined && numValue < min) {
        if (onBlurValidate) {
          // Mostramos advertencia pero no corregimos hasta el blur
          setError(`El valor mínimo es ${min}`);
        } else {
          validatedValue = min;
          setDisplayValue(min.toString());
        }
      }
      
      if (max !== undefined && numValue > max) {
        if (onBlurValidate) {
          // Mostramos advertencia pero no corregimos hasta el blur
          setError(`El valor máximo es ${max}`);
        } else {
          validatedValue = max;
          setDisplayValue(max.toString());
        }
      }
      
      onChange(validatedValue);
    }
  };

  const handleBlur = () => {
    // Si está vacío y no se permite, establecer a 0 o mínimo
    if (displayValue === '') {
      if (!allowEmpty) {
        const defaultValue = (min !== undefined && min > 0) ? min : 0;
        setDisplayValue(defaultValue.toString());
        onChange(defaultValue);
      }
      return;
    }
    
    const numValue = parseFloat(displayValue);
    
    // Validar restricciones al perder el foco
    if (!isNaN(numValue)) {
      let validatedValue = numValue;
      
      if (min !== undefined && numValue < min) {
        validatedValue = min;
        setDisplayValue(min.toString());
        setError(null);
      }
      
      if (max !== undefined && numValue > max) {
        validatedValue = max;
        setDisplayValue(max.toString());
        setError(null);
      }
      
      onChange(validatedValue);
    }
  };
  
  return (
    <div className="relative flex flex-col">
      <Input
        ref={inputRef}
        type="text"
        inputMode="numeric"
        value={displayValue}
        onChange={handleChange}
        onBlur={handleBlur}
        className={cn(error ? 'border-red-500' : '', className)}
        min={min}
        max={max}
        step={step}
        {...props}
      />
      
      {error && (
        <span className="text-xs text-red-500 mt-1">{error}</span>
      )}
    </div>
  );
}
