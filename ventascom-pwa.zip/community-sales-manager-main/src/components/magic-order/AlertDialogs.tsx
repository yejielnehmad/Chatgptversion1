
import React from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface AlertMessageProps {
  alertMessage: { title: string; message: string } | null;
  setAlertMessage: (message: { title: string; message: string } | null) => void;
}

export const AlertMessage: React.FC<AlertMessageProps> = ({
  alertMessage,
  setAlertMessage,
}) => {
  return (
    <AlertDialog 
      open={alertMessage !== null}
      onOpenChange={(open) => !open && setAlertMessage(null)}
    >
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{alertMessage?.title}</AlertDialogTitle>
          <AlertDialogDescription>
            {alertMessage?.message}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogAction>Aceptar</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

interface DeleteOrderDialogProps {
  orderToDelete: {index: number, name: string} | null;
  setOrderToDelete: (order: {index: number, name: string} | null) => void;
  handleConfirmDeleteOrder: () => void;
}

export const DeleteOrderDialog: React.FC<DeleteOrderDialogProps> = ({
  orderToDelete,
  setOrderToDelete,
  handleConfirmDeleteOrder,
}) => {
  return (
    <AlertDialog open={orderToDelete !== null} onOpenChange={(open) => !open && setOrderToDelete(null)}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>¿Eliminar pedido?</AlertDialogTitle>
          <AlertDialogDescription>
            Estás por eliminar el pedido de <strong>{orderToDelete?.name}</strong>. Esta acción no se puede deshacer.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancelar</AlertDialogCancel>
          <AlertDialogAction 
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90" 
            onClick={handleConfirmDeleteOrder}
          >
            Eliminar
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
