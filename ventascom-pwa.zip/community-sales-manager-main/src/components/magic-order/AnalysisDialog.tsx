
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { logError } from '@/lib/debug-utils';
import { safeJsonParse } from '@/lib/json-utils';

interface AnalysisDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  phase1Response: string | null;
  phase2Response: string | null;
  phase3Response: string | null;
}

export const AnalysisDialog: React.FC<AnalysisDialogProps> = ({
  open,
  onOpenChange,
  phase1Response,
  phase2Response,
  phase3Response,
}) => {
  const [activeTab, setActiveTab] = useState<string>("phase1");

  const renderTabContent = (value: string) => {
    if (value === 'phase2' || value === 'phase3') {
      let jsonContent = '';
      
      if (value === 'phase2' && phase2Response) {
        try {
          const parsedJson = safeJsonParse(phase2Response);
          jsonContent = typeof parsedJson === 'string' ? parsedJson : JSON.stringify(parsedJson, null, 2);
        } catch (e) {
          jsonContent = `Error al parsear JSON: ${e}\n\nDatos originales:\n${phase2Response}`;
        }
      } else if (value === 'phase3' && phase3Response) {
        try {
          const parsedJson = safeJsonParse(phase3Response);
          jsonContent = typeof parsedJson === 'string' ? parsedJson : JSON.stringify(parsedJson, null, 2);
        } catch (e) {
          jsonContent = `Error al parsear JSON: ${e}\n\nDatos originales:\n${phase3Response}`;
        }
      } else {
        jsonContent = "No hay datos disponibles para esta fase";
      }
      
      return (
        <div className="flex-1 overflow-auto p-4 border rounded-md mt-4">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-base font-medium">
                {value === 'phase2' ? 'Extracción de datos' : 'Verificación y mapeo'}
              </h3>
            </div>
            
            <div className="whitespace-pre-wrap font-mono text-sm bg-muted/50 p-4 rounded-md overflow-auto max-h-[60vh]">
              {jsonContent}
            </div>
          </div>
        </div>
      );
    } else if (value === 'phase1') {
      return (
        <div className="flex-1 overflow-auto p-4 border rounded-md mt-4">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-base font-medium">Procesamiento de texto</h3>
            </div>
            
            <div className="whitespace-pre-wrap font-mono text-sm bg-muted/50 p-4 rounded-md overflow-auto max-h-[60vh]">
              {phase1Response || "No hay datos disponibles para esta fase"}
            </div>
          </div>
        </div>
      );
    }
    
    return null;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Detalles del análisis</DialogTitle>
          <DialogDescription>
            Visualiza las diferentes fases del procesamiento del mensaje
          </DialogDescription>
        </DialogHeader>
        
        <Tabs 
          defaultValue="phase1" 
          className="flex-1 flex flex-col" 
          value={activeTab} 
          onValueChange={setActiveTab}
        >
          <TabsList>
            <TabsTrigger value="phase1">Fase 1: Procesamiento</TabsTrigger>
            <TabsTrigger value="phase2">Fase 2: Extracción</TabsTrigger>
            <TabsTrigger value="phase3">Fase 3: Verificación</TabsTrigger>
          </TabsList>
          
          {renderTabContent(activeTab)}
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
