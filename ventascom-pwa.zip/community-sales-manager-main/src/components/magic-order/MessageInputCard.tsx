
import React, { useEffect } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Loader2, 
  Clipboard,
  Wand,
  X
} from "lucide-react";

interface MessageInputCardProps {
  message: string;
  setMessage: (message: string) => void;
  isAnalyzing: boolean;
  isLoadingData: boolean;
  progress: number;
  progressStage: string;
  handleAnalyzeMessage: () => void;
  handlePaste: () => void;
  products?: any[];
  clients?: any[];
}

export const MessageInputCard: React.FC<MessageInputCardProps> = ({
  message,
  setMessage,
  isAnalyzing,
  isLoadingData,
  progress,
  progressStage,
  handleAnalyzeMessage,
  handlePaste,
  products,
  clients
}) => {
  const handleClearMessage = () => {
    setMessage("");
  };

  // Aseguramos que el progreso siempre sea un número válido
  const validProgress = typeof progress === 'number' && !isNaN(progress) ? progress : 0;

  // Sincronizamos el estado de análisis con el sistema global
  useEffect(() => {
    if (isAnalyzing) {
      // Si el análisis está empezando (progreso bajo), emitimos evento de inicio
      if (validProgress <= 5) {
        // Disparamos el evento de inicio de análisis
        const startEvent = new CustomEvent('analysisStateChange', {
          detail: { 
            isAnalyzing: true,
            progress: 0,
            stage: "Iniciando análisis...",
            timestamp: new Date().toISOString(),
            source: 'messageInputCard',
            eventType: 'analysis-start'
          }
        });
        window.dispatchEvent(startEvent);
        console.log("MessageInputCard: Iniciando nuevo análisis");
      }
      
      // Guardamos en sessionStorage para persistencia entre navegaciones
      sessionStorage.setItem('magicOrder_isAnalyzing', 'true');
      sessionStorage.setItem('magicOrder_progress', String(validProgress));
      sessionStorage.setItem('magicOrder_stage', progressStage);
      sessionStorage.setItem('magicOrder_timestamp', new Date().toISOString());
      
      // Disparamos un evento para actualizar la barra de progreso global
      const progressEvent = new CustomEvent('analysisStateChange', {
        detail: { 
          isAnalyzing: true,
          progress: validProgress,
          stage: progressStage,
          timestamp: new Date().toISOString(),
          source: 'messageInputCard',
          eventType: 'analysis-progress'
        }
      });
      
      console.log("MessageInputCard: Enviando actualización de progreso:", validProgress, progressStage);
      window.dispatchEvent(progressEvent);
    } else if (!isAnalyzing && validProgress >= 100) {
      // Notificamos finalización del análisis
      const completionEvent = new CustomEvent('analysisStateChange', {
        detail: { 
          isAnalyzing: false,
          progress: 100,
          stage: "Análisis completado",
          isComplete: true,
          timestamp: new Date().toISOString(),
          source: 'messageInputCard',
          eventType: 'analysis-done'
        }
      });
      window.dispatchEvent(completionEvent);
      console.log("MessageInputCard: Análisis completado");
      
      // Limpiamos los datos de sessionStorage cuando el análisis termina correctamente
      sessionStorage.removeItem('magicOrder_isAnalyzing');
      sessionStorage.removeItem('magicOrder_progress');
      sessionStorage.removeItem('magicOrder_stage');
    }
  }, [isAnalyzing, validProgress, progressStage]);

  // Verificamos al montar el componente si hay un análisis en curso
  useEffect(() => {
    // Si hay un análisis en curso según sessionStorage pero el componente no lo sabe,
    // restauramos el estado desde sessionStorage
    const savedIsAnalyzing = sessionStorage.getItem('magicOrder_isAnalyzing');
    
    if (savedIsAnalyzing === 'true' && !isAnalyzing) {
      console.log("MessageInputCard: Detectado análisis en curso al montar componente");
      
      // No hacemos nada aquí porque MagicOrder.tsx debe encargarse de restaurar el estado
      // Solo notificamos que existe un análisis en curso para que otros componentes lo sepan
      const savedProgress = sessionStorage.getItem('magicOrder_progress');
      const savedStage = sessionStorage.getItem('magicOrder_stage');
      
      const event = new CustomEvent('analysisStateChange', {
        detail: { 
          isAnalyzing: true,
          progress: savedProgress ? parseFloat(savedProgress) : 5,
          stage: savedStage || "Análisis en curso...",
          timestamp: new Date().toISOString(),
          source: 'messageInputCard',
          eventType: 'analysis-progress'
        }
      });
      window.dispatchEvent(event);
    }
  }, [isAnalyzing]);

  return (
    <Card className="rounded-xl shadow-sm overflow-hidden">
      <CardHeader className="py-3">
        <CardTitle className="text-base flex items-center justify-between">
          <span>Mensaje del cliente</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-0 pt-0">
        <div className="relative">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ejemplo: Hola, quiero pedir 2 pasteles de chocolate y 1 de vainilla. Gracias!"
            className="min-h-32 resize-y border-muted"
            disabled={isAnalyzing || isLoadingData}
          />

          {message && (
            <Button
              size="icon"
              variant="ghost"
              className="absolute right-2 top-2 h-7 w-7 rounded-full opacity-70 hover:opacity-100"
              onClick={handleClearMessage}
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Limpiar mensaje</span>
            </Button>
          )}
        </div>

        {isAnalyzing && (
          <div className="my-3">
            <div className="flex justify-between items-center mb-1 text-sm">
              <span className="text-muted-foreground">{progressStage}</span>
              <span className="font-medium">{Math.round(validProgress)}%</span>
            </div>
            <Progress 
              value={validProgress} 
              className="h-2" 
              isComplete={validProgress >= 100}
            />
          </div>
        )}
      </CardContent>
      <CardFooter className="py-3 flex justify-between">
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePaste}
            className="flex items-center gap-1"
            disabled={isAnalyzing || isLoadingData}
          >
            <Clipboard className="h-4 w-4" />
            Pegar
          </Button>
        </div>

        <Button
          onClick={handleAnalyzeMessage}
          disabled={isAnalyzing || isLoadingData || !message.trim()}
          className="flex items-center gap-1"
          size="sm"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Analizando...
            </>
          ) : (
            <>
              <Wand className="h-4 w-4" />
              Analizar mensaje
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};
