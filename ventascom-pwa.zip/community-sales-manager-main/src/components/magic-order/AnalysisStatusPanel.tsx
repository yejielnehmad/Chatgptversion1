
import React, { useState, useEffect } from "react";
import { X, AlertCircle, Loader2, CheckCircle, RefreshCcw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { getAnalysisByToken } from "@/lib/supabase";

interface AnalysisStatusPanelProps {
  isAnalyzing: boolean;
  isCheckingPendingAnalysis?: boolean;
  tokenId?: string | null;
  progress?: number;
  progressStage?: string;
}

export const AnalysisStatusPanel: React.FC<AnalysisStatusPanelProps> = ({
  isAnalyzing,
  isCheckingPendingAnalysis = false,
  tokenId = null,
  progress = 0,
  progressStage = "",
}) => {
  const [visible, setVisible] = useState(true);
  const [message, setMessage] = useState("");
  const [lastEvent, setLastEvent] = useState<string | null>(null);
  const [internalProgress, setInternalProgress] = useState(progress);

  // Función para obtener el mensaje según el estado
  const getStatusMessage = () => {
    if (isCheckingPendingAnalysis) {
      return "Verificando si existe un análisis anterior pendiente...";
    }
    
    if (isAnalyzing) {
      return progressStage || "Análisis en curso...";
    }
    
    if (progress >= 100) {
      return "Análisis completado correctamente";
    }
    
    if (tokenId) {
      return "Análisis recuperado de una sesión anterior";
    }
    
    return "No hay análisis en curso";
  };

  // Cuando cambian las props, actualizamos el mensaje y el progreso interno
  useEffect(() => {
    setMessage(getStatusMessage());
    setInternalProgress(progress);
  }, [isAnalyzing, isCheckingPendingAnalysis, progress, progressStage, tokenId]);

  // Verificamos si hay un análisis activo en Supabase al cargar el componente
  useEffect(() => {
    const checkAnalysisInSupabase = async () => {
      // Solo verificamos en Supabase si tenemos un tokenId
      if (tokenId) {
        try {
          const analysis = await getAnalysisByToken(tokenId);
          if (analysis && analysis.status === 'analyzing') {
            // Si hay un análisis activo, aseguramos que el panel sea visible
            setVisible(true);
            
            // Actualizamos el mensaje y el progreso según los datos de Supabase
            if (analysis.stage) {
              setMessage(analysis.stage);
            }
            
            if (analysis.progress) {
              setInternalProgress(analysis.progress);
            }
            
            // Disparamos un evento para sincronizar otros componentes
            const event = new CustomEvent('analysisStateChange', {
              detail: { 
                isAnalyzing: true,
                stage: analysis.stage || "Análisis en curso...",
                progress: analysis.progress || 5,
                tokenId: tokenId,
                source: 'supabase-check'
              }
            });
            window.dispatchEvent(event);
          }
        } catch (error) {
          console.error("Error al verificar análisis en Supabase:", error);
        }
      }
    };
    
    // Verificamos al montar el componente
    checkAnalysisInSupabase();
    
    // Configuramos una verificación periódica cada 30 segundos
    const intervalId = setInterval(checkAnalysisInSupabase, 30000);
    
    return () => {
      clearInterval(intervalId);
    };
  }, [tokenId]);

  // Escuchar eventos globales de cambio de estado
  useEffect(() => {
    const handleAnalysisStateChange = (event: CustomEvent) => {
      const { eventType, tokenId: eventTokenId, isComplete, progress: eventProgress, stage } = event.detail;
      
      // Cuando recibimos un evento, mostramos el panel si está oculto
      if (!visible) {
        setVisible(true);
      }
      
      setLastEvent(eventType);
      
      let newMessage = "";
      
      switch(eventType) {
        case 'analysis-start':
          newMessage = "Iniciando nuevo análisis...";
          break;
        case 'analysis-progress':
          newMessage = event.detail.stage || "Análisis en curso...";
          if (eventProgress !== undefined) {
            setInternalProgress(eventProgress);
          }
          break;
        case 'analysis-done':
          newMessage = "¡Análisis completado correctamente!";
          setInternalProgress(100);
          break;
        default:
          if (event.detail.isAnalyzing) {
            newMessage = event.detail.stage || "Análisis en curso...";
            if (eventProgress !== undefined) {
              setInternalProgress(eventProgress);
            }
          } else if (isComplete) {
            newMessage = "Análisis completado correctamente";
            setInternalProgress(100);
          } else if (eventTokenId) {
            newMessage = "Análisis recuperado de una sesión anterior";
          }
      }
      
      if (newMessage) {
        setMessage(newMessage);
      }
    };
    
    window.addEventListener('analysisStateChange', handleAnalysisStateChange as EventListener);
    
    return () => {
      window.removeEventListener('analysisStateChange', handleAnalysisStateChange as EventListener);
    };
  }, [visible]);

  if (!visible) {
    return (
      <Button
        variant="outline"
        size="sm"
        className="fixed bottom-4 right-4 z-50 rounded-full shadow-md"
        onClick={() => setVisible(true)}
      >
        <AlertCircle className="h-4 w-4 mr-1" />
        Estado
      </Button>
    );
  }

  // Determinamos el icono a mostrar según el estado
  let statusIcon;
  if (isCheckingPendingAnalysis) {
    statusIcon = <RefreshCcw className="h-5 w-5 text-blue-500 animate-spin" />;
  } else if (isAnalyzing) {
    statusIcon = <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
  } else if (internalProgress >= 100) {
    statusIcon = <CheckCircle className="h-5 w-5 text-green-500" />;
  } else {
    statusIcon = <AlertCircle className="h-5 w-5 text-blue-500" />;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm">
      <Card className="shadow-lg border-t-4 border-t-primary">
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              {statusIcon}
              <div className="w-full">
                <div className="font-medium text-sm">Estado del análisis</div>
                <div className="text-sm text-muted-foreground mt-1">{message}</div>
                
                {internalProgress > 0 && internalProgress < 100 && (
                  <Progress 
                    value={internalProgress} 
                    className="h-1 mt-2 w-full"
                    isComplete={internalProgress >= 100}
                  />
                )}
                
                {tokenId && (
                  <Badge variant="outline" className="mt-2 text-xs">
                    ID: {tokenId.substring(0, 8)}...
                  </Badge>
                )}
                
                {lastEvent && (
                  <div className="text-xs text-muted-foreground mt-1">
                    Último evento: {lastEvent}
                  </div>
                )}
              </div>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 rounded-full"
              onClick={() => setVisible(false)}
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Cerrar</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
