
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SimpleOrderCardNew } from "@/components/SimpleOrderCardNew";
import { 
  ChevronUp, 
  ChevronDown, 
  Check, 
  Loader2, 
  AlertCircle,
  User,
  Clock
} from "lucide-react";
import { 
  Collapsible,
  CollapsibleContent,
} from "@/components/ui/collapsible";
import { OrderCard as OrderCardType } from "@/types";
import { Separator } from "@/components/ui/separator";
import { AnalysisStatusPanel } from "@/components/magic-order/AnalysisStatusPanel";

interface OrdersResultSectionProps {
  orders: OrderCardType[];
  showOrderSummary: boolean;
  setShowOrderSummary: (show: boolean) => void;
  handleSaveAllOrders: () => void;
  handleUpdateOrder: (index: number, updatedOrder: OrderCardType) => void;
  handleSaveOrder: (orderIndex: number, order: OrderCardType) => Promise<boolean>;
  handleDeleteOrder: (index: number) => void;
  handleResetAllOrders: () => void;
  products: any[];
  clients: any[];
  isSavingAllOrders: boolean;
  allOrdersComplete: boolean;
  isCheckingPendingAnalysis?: boolean;
}

export const OrdersResultSection: React.FC<OrdersResultSectionProps> = ({
  orders,
  showOrderSummary,
  setShowOrderSummary,
  handleSaveAllOrders,
  handleUpdateOrder,
  handleSaveOrder,
  handleDeleteOrder,
  products,
  clients,
  isSavingAllOrders,
  allOrdersComplete,
  isCheckingPendingAnalysis = false
}) => {
  // Si está cargando un análisis anterior, mostrar indicador
  if (isCheckingPendingAnalysis) {
    return (
      <div className="space-y-4">
        <Card className="rounded-xl overflow-hidden bg-muted/10 border">
          <CardContent className="p-4">
            <div className="flex gap-2 items-center justify-center py-6">
              <Loader2 className="h-5 w-5 text-primary animate-spin" />
              <p className="text-muted-foreground">
                Cargando análisis anterior...
              </p>
            </div>
          </CardContent>
        </Card>
        
        <AnalysisStatusPanel 
          isAnalyzing={false}
          isCheckingPendingAnalysis={true}
        />
      </div>
    );
  }

  // Si no hay órdenes, no mostrar nada excepto el panel de estado
  if (orders.length === 0) {
    return (
      <AnalysisStatusPanel 
        isAnalyzing={false}
        isCheckingPendingAnalysis={isCheckingPendingAnalysis}
      />
    );
  }

  // Calculamos órdenes incompletas
  const incompleteOrders = orders.filter(order => 
    !order.client.id || 
    order.client.matchConfidence !== 'alto' || 
    order.items.some(item => item.status === 'duda' || !item.product.id || !item.quantity)
  );

  // Organizamos pedidos por cliente
  const ordersByClient = orders.reduce((acc, order, index) => {
    const clientId = order.client.id || `unknown-${index}`;
    const clientName = order.client.name;
    
    if (!acc[clientId]) {
      acc[clientId] = {
        clientName,
        orders: [],
        indices: []
      };
    }
    
    acc[clientId].orders.push(order);
    acc[clientId].indices.push(index);
    
    return acc;
  }, {} as Record<string, { clientName: string, orders: OrderCardType[], indices: number[] }>);

  // Emitir evento para actualizar la barra de progreso global al terminar
  React.useEffect(() => {
    if (orders.length > 0) {
      // Notificamos que el análisis ha terminado y hay órdenes
      const event = new CustomEvent('analysisStateChange', {
        detail: { 
          isAnalyzing: false,
          progress: 100,
          stage: "Análisis completado",
          ordersCount: orders.length,
          isComplete: true,
          timestamp: new Date().toISOString(),
          eventType: 'analysis-done'
        }
      });
      window.dispatchEvent(event);
    }
  }, [orders.length]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">
          Pedidos detectados ({orders.length})
        </h2>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowOrderSummary(!showOrderSummary)}
            className="flex items-center gap-1"
          >
            {showOrderSummary ? (
              <>
                <ChevronUp className="h-4 w-4" />
                Ocultar pedidos
              </>
            ) : (
              <>
                <ChevronDown className="h-4 w-4" />
                Mostrar pedidos ({orders.length})
              </>
            )}
          </Button>
          
          <Button
            size="sm"
            onClick={handleSaveAllOrders}
            disabled={isSavingAllOrders || !allOrdersComplete}
            className="flex items-center gap-1"
          >
            {isSavingAllOrders ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <Check className="h-4 w-4" />
                Guardar todos
              </>
            )}
          </Button>
        </div>
      </div>
      
      <Collapsible open={showOrderSummary}>
        <CollapsibleContent className="space-y-6">
          {/* Contador de problemas */}
          {incompleteOrders.length > 0 && (
            <Card className="rounded-xl overflow-hidden bg-amber-50 dark:bg-yellow-900/20 border-amber-200 dark:border-yellow-800">
              <CardContent className="p-4">
                <div className="flex gap-2 items-center">
                  <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-500" />
                  <p className="text-amber-600 dark:text-amber-500">
                    <strong>Atención:</strong> Hay {incompleteOrders.length} pedido{incompleteOrders.length !== 1 ? 's' : ''} con detalles por confirmar
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
          
          {/* Organizar pedidos por cliente */}
          {Object.entries(ordersByClient).map(([clientId, { clientName, orders: clientOrders, indices }]) => (
            <div key={clientId} className="space-y-3">
              <div className="flex items-center gap-2">
                <User className="h-5 w-5 text-muted-foreground" />
                <h3 className="text-lg font-medium">{clientName}</h3>
                <Badge variant="outline">{clientOrders.length} pedido{clientOrders.length !== 1 ? 's' : ''}</Badge>
              </div>
              
              <div className="space-y-4">
                {clientOrders.map((order, i) => (
                  <SimpleOrderCardNew
                    key={`order-${indices[i]}`}
                    order={order}
                    onUpdateOrder={(updatedOrder) => handleUpdateOrder(indices[i], updatedOrder)}
                    onSaveOrder={() => handleSaveOrder(indices[i], order)}
                    onDeleteOrder={() => handleDeleteOrder(indices[i])}
                    products={products}
                    clients={clients}
                  />
                ))}
              </div>
            </div>
          ))}
        </CollapsibleContent>
      </Collapsible>
      
      <AnalysisStatusPanel 
        isAnalyzing={isSavingAllOrders}
        isCheckingPendingAnalysis={isCheckingPendingAnalysis}
        progress={isSavingAllOrders ? 50 : 100}
        progressStage={isSavingAllOrders ? "Guardando pedidos..." : ""}
      />
    </div>
  );
};
