
import React from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export interface Variant {
  id: string;
  name: string;
  price?: number;
}

interface VariantSelectorProps {
  variants: Variant[];
  selectedVariantId?: string;
  onSelectVariant: (variantId: string) => void;
  className?: string;
}

export const VariantSelector: React.FC<VariantSelectorProps> = ({
  variants,
  selectedVariantId,
  onSelectVariant,
  className
}) => {
  if (!variants || variants.length === 0) {
    return null;
  }

  return (
    <div className={cn("mt-2", className)}>
      <div className="text-xs font-medium mb-1 text-amber-700">
        Selecciona una variante:
      </div>
      <div className="flex flex-wrap gap-1">
        {variants.map((variant) => (
          <Badge 
            key={variant.id} 
            variant={selectedVariantId === variant.id ? "default" : "outline"}
            className={cn(
              "cursor-pointer transition-colors text-xs",
              selectedVariantId === variant.id 
                ? "bg-primary text-primary-foreground" 
                : "hover:bg-primary/10"
            )}
            onClick={() => onSelectVariant(variant.id)}
          >
            {variant.name}
            {variant.price !== undefined && ` ($${variant.price.toFixed(2)})`}
          </Badge>
        ))}
      </div>
    </div>
  );
};
