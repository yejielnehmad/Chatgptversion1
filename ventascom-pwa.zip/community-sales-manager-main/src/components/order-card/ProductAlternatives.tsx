
import React from "react";
import { HelpCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export interface Alternative {
  id: string;
  name: string;
  price?: number;
}

interface ProductAlternativesProps {
  alternatives: Alternative[];
  onSelectAlternative: (id: string) => void;
  title?: string;
  helpText?: string;
  className?: string;
}

export const ProductAlternatives: React.FC<ProductAlternativesProps> = ({
  alternatives,
  onSelectAlternative,
  title = "¿Te refieres a alguno de estos?",
  helpText,
  className
}) => {
  if (!alternatives || alternatives.length === 0) {
    return null;
  }
  
  return (
    <div className={cn("mt-2", className)}>
      <div className="flex flex-wrap gap-1">
        {alternatives.map((alt) => (
          <Badge 
            key={alt.id}
            variant="outline" 
            className="cursor-pointer hover:bg-accent transition-colors"
            onClick={() => onSelectAlternative(alt.id)}
          >
            {alt.name}
            {alt.price !== undefined && ` ($${alt.price.toFixed(2)})`}
          </Badge>
        ))}
      </div>
      <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 w-fit mt-1">
        <HelpCircle size={12} className="mr-1" />
        {helpText || title}
      </Badge>
    </div>
  );
};
