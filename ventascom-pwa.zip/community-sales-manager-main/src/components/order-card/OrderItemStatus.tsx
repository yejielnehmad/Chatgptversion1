
import React from "react";
import { AlertCircle, Check, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface OrderItemStatusProps {
  isLoading: boolean;
  needsAttention: boolean;
  hasVariantIssue?: boolean;
  hasQuantityIssue?: boolean;
}

export const OrderItemStatus: React.FC<OrderItemStatusProps> = ({
  isLoading,
  needsAttention,
  hasVariantIssue,
  hasQuantityIssue
}) => {
  return (
    <Badge variant={needsAttention ? "outline" : "secondary"} 
      className={cn(
        needsAttention 
          ? "bg-amber-50 text-amber-700 border-amber-200" 
          : "bg-green-50 text-green-700 border-green-200"
      )}
    >
      {isLoading ? (
        <>
          <Loader2 size={12} className="mr-1 animate-spin" />
          Cargando...
        </>
      ) : needsAttention ? (
        <>
          <AlertCircle size={12} className="mr-1" />
          {hasVariantIssue ? "Falta variante" : hasQuantityIssue ? "Falta cantidad" : "Requiere confirmar"}
        </>
      ) : (
        <>
          <Check size={12} className="mr-1" />
          OK
        </>
      )}
    </Badge>
  );
};
