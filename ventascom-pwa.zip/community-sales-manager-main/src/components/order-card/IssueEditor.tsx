
import React from "react";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageItem } from "@/types";

interface IssueEditorProps {
  item: MessageItem;
  itemIndex: number;
  customQuantity: number | null;
  setCustomQuantity: (quantity: number | null) => void;
  setEditingItemIndex: (index: number | null) => void;
  needsVariantSelection: boolean;
  handleResolveIssue: (index: number) => void;
  onDeleteOrder: () => void;
}

export const IssueEditor: React.FC<IssueEditorProps> = ({
  item,
  itemIndex,
  customQuantity,
  setCustomQuantity,
  setEditingItemIndex,
  needsVariantSelection,
  handleResolveIssue,
  onDeleteOrder
}) => {
  // Verificar si el problema es relacionado con cantidades
  const isQuantityIssue = 
    item.notes?.toLowerCase().includes('cantidad') ||
    item.notes?.toLowerCase().includes('cuánto') ||
    item.notes?.toLowerCase().includes('cuántos') ||
    item.notes?.toLowerCase().includes('cuántas') ||
    !item.quantity;

  if (isQuantityIssue) {
    return (
      <div className="mt-2">
        <div className="text-xs font-medium mb-1 text-amber-700">
          Corregir cantidad:
        </div>
        <div className="flex items-center gap-2">
          <Input
            type="number"
            min="1"
            className="w-24 h-8 border-amber-300 bg-amber-50 text-amber-800"
            placeholder="Cantidad"
            value={customQuantity !== null ? customQuantity : item.quantity || ''}
            onChange={(e) => setCustomQuantity(parseInt(e.target.value) || 0)}
            onFocus={() => setEditingItemIndex(itemIndex)}
          />
          {!needsVariantSelection && (
            <Button 
              size="sm" 
              variant="outline" 
              className="h-8 border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100"
              onClick={() => handleResolveIssue(itemIndex)}
            >
              <Check className="h-3 w-3 mr-1" />
              Confirmar
            </Button>
          )}
        </div>
      </div>
    );
  }

  // Para dudas genéricas sin opciones específicas
  return (
    <div className="mt-2">
      <div className="text-xs font-medium mb-1 text-amber-700">
        Opciones de resolución:
      </div>
      <div className="flex flex-wrap gap-2">
        {!needsVariantSelection && (
          <Button 
            size="sm" 
            variant="outline" 
            className="h-8 border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100"
            onClick={() => handleResolveIssue(itemIndex)}
            disabled={needsVariantSelection}
          >
            <Check className="h-3 w-3 mr-1" />
            Marcar como correcto
          </Button>
        )}
        {/* Mostrar botón de eliminar solo si no hay selección de variante pendiente */}
        {!needsVariantSelection && (
          <Button 
            size="sm" 
            variant="outline" 
            className="h-8 border-red-300 bg-red-50 text-red-800 hover:bg-red-100"
            onClick={onDeleteOrder}
          >
            Eliminar pedido
          </Button>
        )}
      </div>
    </div>
  );
};
