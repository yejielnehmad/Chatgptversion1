
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { getAnalysisByToken } from "@/lib/api";

export default function GlobalProgressBar() {
  const [status, setStatus] = useState<"idle" | "in_progress" | "done">("idle");
  const [progress, setProgress] = useState(0);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const token = sessionStorage.getItem("tokenId");
    if (!token) return;

    let channel: any = null;

    async function init() {
      const analysis = await getAnalysisByToken(token);
      if (!analysis) return;

      if (analysis.analysis_status === "in_progress" || analysis.analysis_status === "queued") {
        setStatus("in_progress");
        setProgress(analysis.progress || 0);
        setVisible(true);
      }

      channel = supabase
        .channel("realtime-analysis")
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "magic_orders",
            filter: `token_id=eq.${token}`,
          },
          (payload) => {
            const updated = payload.new;
            if (updated.analysis_status === "done") {
              setProgress(100);
              setStatus("done");
              setTimeout(() => {
                setVisible(false);
                setStatus("idle");
                setProgress(0);
              }, 2000);
            } else if (updated.analysis_status === "in_progress") {
              setStatus("in_progress");
              setVisible(true);
              setProgress(updated.progress || progress);
            }
          }
        )
        .subscribe();
    }

    init();

    return () => {
      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, []);

  if (!visible) return null;

  return (
    <div style={{
      position: "fixed",
      top: 56,
      left: 0,
      width: "100%",
      height: "4px",
      backgroundColor: "#E5E7EB",
      zIndex: 9999
    }}>
      <div style={{
        width: `${progress}%`,
        height: "100%",
        transition: "width 0.3s ease",
        backgroundColor: status === "done" ? "#22C55E" : "#3B82F6"
      }} />
    </div>
  );
}
