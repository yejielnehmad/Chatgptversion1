import { useState, useEffect } from 'react';
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Wand, Sparkles, FileText, RefreshCcw } from 'lucide-react';
import { supabase, analyzeWithoutDB } from "@/lib/supabase";
import { 
  analyzeCustomerMessage, 
  GeminiError,
  getCurrentApiProvider,
  getCurrentGeminiModel,
  ApiProvider,
  getAnalysisByToken,
  updateAnalysisStatus
} from "@/services/geminiService";
import { OrderCard as OrderCardType } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { GOOGLE_GEMINI_MODELS } from "@/lib/api-config";
import { logDebug, logError } from '@/lib/debug-utils';
import { AIConfigCard } from '@/components/magic-order/AIConfigCard';
import { MessageInputCard } from '@/components/magic-order/MessageInputCard';
import { OrdersResultSection } from '@/components/magic-order/OrdersResultSection';
import { AnalysisDialog } from '@/components/magic-order/AnalysisDialog';
import { AlertMessage, DeleteOrderDialog } from '@/components/magic-order/AlertDialogs';
import { safeJsonParse } from '@/lib/json-utils';

/**
 * Página Mensaje Mágico
 * v1.0.83 - Solo Google Gemini como proveedor de IA
 */
const MagicOrder = () => {
  // Recuperar estado del localStorage al cargar la página
  const [message, setMessage] = useState(() => {
    const savedMessage = localStorage.getItem('magicOrder_message');
    return savedMessage || "";
  });
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const [orders, setOrders] = useState<OrderCardType[]>(() => {
    const savedOrders = localStorage.getItem('magicOrder_orders');
    return savedOrders ? JSON.parse(savedOrders) : [];
  });
  
  const [showOrderSummary, setShowOrderSummary] = useState(() => {
    const savedShowOrderSummary = localStorage.getItem('magicOrder_showOrderSummary');
    return savedShowOrderSummary ? JSON.parse(savedShowOrderSummary) : true;
  });
  
  const [alertMessage, setAlertMessage] = useState<{ title: string; message: string } | null>(null);
  const [orderToDelete, setOrderToDelete] = useState<{index: number, name: string} | null>(null);
  const [isSavingAllOrders, setIsSavingAllOrders] = useState(false);
  
  const [clients, setClients] = useState<any[]>(() => {
    const savedClients = localStorage.getItem('magicOrder_clients');
    return savedClients ? JSON.parse(savedClients) : [];
  });
  
  const [products, setProducts] = useState<any[]>(() => {
    const savedProducts = localStorage.getItem('magicOrder_products');
    return savedProducts ? JSON.parse(savedProducts) : [];
  });
  
  const [analyzeError, setAnalysisError] = useState<string | null>(null);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [progressStage, setProgressStage]
const [showAnalyzingFeedback, setShowAnalyzingFeedback] = useState(false); = useState<string>("");
  
  const [phase1Response, setPhase1Response] = useState<string | null>(() => {
    const savedPhase1 = localStorage.getItem('magicOrder_phase1Response');
    return savedPhase1 || null;
  });
  
  const [phase2Response, setPhase2Response] = useState<string | null>(() => {
    const savedPhase2 = localStorage.getItem('magicOrder_phase2Response');
    return savedPhase2 || null;
  });
  
  const [phase3Response, setPhase3Response] = useState<string | null>(() => {
    const savedPhase3 = localStorage.getItem('magicOrder_phase3Response');
    return savedPhase3 || null;
  });
  
  const [showAnalysisDialog, setShowAnalysisDialog] = useState(false);
  const { toast } = useToast();
  
  // Solo mantenemos Google Gemini como proveedor
  const [apiProvider] = useState<ApiProvider>("google-gemini");
  
  // Solo mantenemos el modelo Gemini 2.0 Flash
  const [geminiModel] = useState<string>(GOOGLE_GEMINI_MODELS.GEMINI_FLASH_2);
  
  // Estado para el tiempo de análisis
  const [analysisTime, setAnalysisTime] = useState<number | null>(null);
  
  // Estado para el ID del análisis
  const [analysisId, setAnalysisId] = useState<string | null>(null);
  const [tokenId, setTokenId] = useState<string | null>(null);
  
  // Estado para controlar si estamos comprobando un análisis pendiente
  const [isCheckingPendingAnalysis, setIsCheckingPendingAnalysis] = useState(true);
  
  // Guardar estado en localStorage cuando cambie
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    localStorage.setItem('magicOrder_message', message);
  }, [message]);
  
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    if (orders.length > 0) {
      localStorage.setItem('magicOrder_orders', JSON.stringify(orders));
    }
  }, [orders]);
  
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    localStorage.setItem('magicOrder_showOrderSummary', JSON.stringify(showOrderSummary));
  }, [showOrderSummary]);
  
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    if (clients.length > 0) {
      localStorage.setItem('magicOrder_clients', JSON.stringify(clients));
    }
  }, [clients]);
  
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    if (products.length > 0) {
      localStorage.setItem('magicOrder_products', JSON.stringify(products));
    }
  }, [products]);
  
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    if (phase1Response) {
      localStorage.setItem('magicOrder_phase1Response', phase1Response);
    }
  }, [phase1Response]);
  
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    if (phase2Response) {
      localStorage.setItem('magicOrder_phase2Response', phase2Response);
    }
  }, [phase2Response]);
  
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    if (phase3Response) {
      localStorage.setItem('magicOrder_phase3Response', phase3Response);
    }
  }, [phase3Response]);

  // Verificar si hay un análisis pendiente al cargar la página
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    const checkPendingAnalysis = async () => {
      setIsCheckingPendingAnalysis(true);
      
      try {
        // Verificar si hay un token de análisis en sessionStorage
        const savedTokenId = sessionStorage.getItem('aiTokenId');
        
        if (savedTokenId) {
          logDebug("MagicOrder", `Comprobando análisis pendiente con token: ${savedTokenId}`);
          
          // Buscar el análisis por token
          const analysis = await getAnalysisByToken(savedTokenId);
          
          if (analysis) {
            logDebug("MagicOrder", `Análisis encontrado con estado: ${analysis.status}`);
            
            setTokenId(savedTokenId);
            
            if (analysis.status === 'completed') {
              // Si el análisis está completo, cargar los resultados
              if (analysis.id) {
                setAnalysisId(analysis.id);
              }
              
              if (analysis.result) {
                // Asegurarnos de que orders está vacío antes de establecer los nuevos resultados
                setOrders([]);
                
                // Pequeño timeout para asegurar que el estado se actualiza correctamente
                setTimeout(() => {
                  setOrders(analysis.result);
                  setShowOrderSummary(true);
                  
                  // Guardar en localStorage para persistencia
                  localStorage.setItem('magicOrder_orders', JSON.stringify(analysis.result));
                }, 100);
              }
              
              if (analysis.phase1_response) {
                setPhase1Response(analysis.phase1_response);
                localStorage.setItem('magicOrder_phase1Response', analysis.phase1_response);
              }
              
              if (analysis.phase2_response) {
                setPhase2Response(analysis.phase2_response);
                localStorage.setItem('magicOrder_phase2Response', analysis.phase2_response);
              }
              
              if (analysis.phase3_response) {
                setPhase3Response(analysis.phase3_response);
                localStorage.setItem('magicOrder_phase3Response', analysis.phase3_response);
              }
              
              if (analysis.analysis_time) {
                setAnalysisTime(analysis.analysis_time);
              }
              
              toast({
                title: "Análisis recuperado",
                description: "Se ha cargado un análisis anterior completado",
                variant: "success"
              });
            } else if (analysis.status === 'analyzing' || analysis.status === 'queued') {
              // Si el análisis está en curso, mostrar el progreso
              setIsAnalyzing(true);
              setProgress(analysis.progress || 5);
              setProgressStage(analysis.stage || "Análisis en curso...");
              
              // Suscribirse a actualizaciones
              const event = new CustomEvent('analysisStateChange', {
                detail: { 
                  isAnalyzing: true,
                  stage: analysis.stage || "Análisis en curso...",
                  tokenId: savedTokenId
                }
              });
              window.dispatchEvent(event);
            } else if (analysis.status === 'error') {
              // Si el análisis tiene un error, mostrar el mensaje
              setAnalysisError(analysis.error_message || "Error desconocido en el análisis");
              
              if (analysis.phase1_response) {
                setPhase1Response(analysis.phase1_response);
                localStorage.setItem('magicOrder_phase1Response', analysis.phase1_response);
              }
              
              if (analysis.phase2_response) {
                setPhase2Response(analysis.phase2_response);
                localStorage.setItem('magicOrder_phase2Response', analysis.phase2_response);
              }
              
              if (analysis.phase3_response) {
                setPhase3Response(analysis.phase3_response);
                localStorage.setItem('magicOrder_phase3Response', analysis.phase3_response);
              }
              
              toast({
                title: "Error en análisis anterior",
                description: analysis.error_message || "Hubo un error en el análisis anterior",
                variant: "destructive"
              });
            }
          } else {
            // Si no se encontró el análisis pero había un token, limpiar el token
            sessionStorage.removeItem('aiTokenId');
            sessionStorage.removeItem('aiStatus');
            sessionStorage.removeItem('aiMessage');
            sessionStorage.removeItem('aiDetailedInfo');
            localStorage.removeItem('magicOrder_backgroundAnalysis');
          }
        } else {
          // Verificar si hay un análisis en localStorage
          const backgroundAnalysis = localStorage.getItem('magicOrder_backgroundAnalysis');
          if (backgroundAnalysis) {
            try {
              const parsedAnalysis = JSON.parse(backgroundAnalysis);
              if (parsedAnalysis.tokenId) {
                // Intentar recuperar el análisis con el token
                const analysis = await getAnalysisByToken(parsedAnalysis.tokenId);
                if (analysis && analysis.status === 'completed' && analysis.result) {
                  setTokenId(parsedAnalysis.tokenId);
                  setOrders(analysis.result);
                  setShowOrderSummary(true);
                  localStorage.setItem('magicOrder_orders', JSON.stringify(analysis.result));
                  
                  if (analysis.phase1_response) {
                    setPhase1Response(analysis.phase1_response);
                    localStorage.setItem('magicOrder_phase1Response', analysis.phase1_response);
                  }
                  
                  if (analysis.phase2_response) {
                    setPhase2Response(analysis.phase2_response);
                    localStorage.setItem('magicOrder_phase2Response', analysis.phase2_response);
                  }
                  
                  if (analysis.phase3_response) {
                    setPhase3Response(analysis.phase3_response);
                    localStorage.setItem('magicOrder_phase3Response', analysis.phase3_response);
                  }
                  
                  toast({
                    title: "Análisis recuperado",
                    description: "Se ha cargado un análisis completado en segundo plano",
                    variant: "success"
                  });
                }
              }
            } catch (error) {
              console.error("Error al parsear análisis en segundo plano:", error);
              localStorage.removeItem('magicOrder_backgroundAnalysis');
            }
          }
        }
      } catch (error) {
        logError("MagicOrder", "Error al comprobar análisis pendiente:", error);
      } finally {
        setIsCheckingPendingAnalysis(false);
      }
    };
    
    checkPendingAnalysis();
  }, [toast]);
  
  // Verificar si existen datos en local storage y cargar desde la base de datos solo si no hay datos locales
  useEffect(() => {
    async function syncFromSupabase() {
      const savedTokenId = sessionStorage.getItem("tokenId");
      if (!savedTokenId) return;
      const analysis = await getAnalysisByToken(savedTokenId);
      if (analysis && analysis.analysis_status === "in_progress") {
        setIsAnalyzing(true);
        setShowAnalyzingFeedback(true);
      }
    }
    syncFromSupabase();
    const loadContextData = async () => {
      // Solo cargar datos si no hay ya datos en localStorage
      if (clients.length === 0 || products.length === 0) {
        setIsLoadingData(true);
        try {
          const { data: clientsData, error: clientsError } = await supabase
            .from('clients')
            .select('id, name, phone');
          
          if (clientsError) throw new Error(clientsError.message);
          if (clientsData && clientsData.length > 0) setClients(clientsData);
          
          const { data: productsData, error: productsError } = await supabase
            .from('products')
            .select('id, name, price, description');
          
          if (productsError) throw new Error(productsError.message);
          
          if (productsData && productsData.length > 0) {
            const { data: variantsData, error: variantsError } = await supabase
              .from('product_variants')
              .select('id, product_id, name, price');
            
            if (variantsError) throw new Error(variantsError.message);
            
            const productsWithVariants = productsData.map(product => {
              const productVariants = variantsData ? variantsData.filter(v => v.product_id === product.id) : [];
              return {
                ...product,
                variants: productVariants
              };
            });
            
            setProducts(productsWithVariants);
          }
        } catch (error) {
          console.error("Error al cargar datos de contexto:", error);
          toast({
            title: "Error al cargar datos",
            description: "No se pudieron cargar todos los productos y clientes",
            variant: "destructive"
          });
        } finally {
          setIsLoadingData(false);
        }
      }
    };
    
    loadContextData();
  }, [toast, clients.length, products.length]);

  // Función para actualizar el progreso del análisis
  const updateProgress = (value: number, stage?: string) => {
    setProgress(value);
    if (stage) setProgressStage(stage);
    
    // Disparamos un evento para actualizar la insignia AI
    const event = new CustomEvent('analysisStateChange', {
      detail: { 
        isAnalyzing: value > 0 && value < 100,
        stage: stage,
        tokenId: tokenId
      }
    });
    window.dispatchEvent(event);
  };

  const handleAnalyzeMessage = async () => {
    if (!message.trim()) {
      setAlertMessage({
        title: "Campo vacío",
        message: "Por favor, ingresa un mensaje para analizar"
      });
      return;
    }

    // Limpiar pedidos anteriores
    setOrders([]);
    setAnalysisId(null);
    
    // Mantenemos el token para poder rastrear el análisis
    if (tokenId) {
      localStorage.removeItem('magicOrder_orders');
    }
    
    setIsAnalyzing(true);
    setAnalysisError(null);
    setPhase1Response(null);
    setPhase2Response(null);
    setPhase3Response(null);
    setProgress(5);
    setProgressStage("Preparando análisis...");
    setAnalysisTime(null);
    
    // Guardamos el mensaje para procesarlo
    const messageToAnalyze = message;
    
    // Limpiamos el campo de mensaje para que el usuario pueda seguir trabajando
    setMessage("");
    
    // Disparamos un evento para actualizar la insignia AI
    const event = new CustomEvent('analysisStateChange', {
      detail: { 
        isAnalyzing: true,
        stage: "Preparando análisis..." 
      }
    });
    window.dispatchEvent(event);

    try {
      // Procesamos el mensaje en segundo plano
      const result = await analyzeCustomerMessage(messageToAnalyze, updateProgress);
      
      if (result.id) {
        setAnalysisId(result.id);
      }
      
      if (result.tokenId) {
        setTokenId(result.tokenId);
        
        // Guardamos el tokenId en sessionStorage para recuperarlo entre navegaciones
        sessionStorage.setItem('aiTokenId', result.tokenId);
      }
      
      if (result.phase1Response) {
        setPhase1Response(result.phase1Response);
        localStorage.setItem('magicOrder_phase1Response', result.phase1Response);
      }
      
      if (result.phase2Response) {
        setPhase2Response(result.phase2Response);
        localStorage.setItem('magicOrder_phase2Response', result.phase2Response);
      }
      
      if (result.phase3Response) {
        setPhase3Response(result.phase3Response);
        localStorage.setItem('magicOrder_phase3Response', result.phase3Response);
      }
      
      if (result.elapsedTime) {
        setAnalysisTime(result.elapsedTime);
      }
      
      setProgress(100);
      setProgressStage("¡Análisis completado!");
      
      const newOrders = result.result.map(result => {
        const processedItems = result.items.map(item => {
          let status: 'duda' | 'confirmado' = item.status as 'duda' | 'confirmado' || 'duda';
          let notes = item.notes || '';
          
          if (item.product?.id) {
            const productInfo = products.find(p => p.id === item.product.id);
            
            if (productInfo && productInfo.variants && productInfo.variants.length > 0) {
              if (!item.variant || !item.variant.id) {
                status = 'duda';
                notes = `No se especificó la variante de ${productInfo.name}`;
              }
            }
          }
          
          return {
            ...item,
            status,
            notes
          };
        });
        
        return {
          client: {
            ...result.client,
            matchConfidence: (result.client.matchConfidence as 'alto' | 'medio' | 'bajo') || 'bajo'
          },
          items: processedItems,
          isPaid: false,
          status: 'pending' as const
        };
      });
      
      if (newOrders.length === 0) {
        setAlertMessage({
          title: "No se encontraron pedidos",
          message: "No se pudo identificar ningún pedido en el mensaje. Intenta con un formato más claro, por ejemplo: 'nombre 2 producto'"
        });
      } else {
        setOrders(newOrders);
        setShowOrderSummary(true);
        
        // Guardar en localStorage para persistencia
        localStorage.setItem('magicOrder_orders', JSON.stringify(newOrders));
        
        // Notificamos mediante evento para que se muestre incluso si el usuario no está en esta página
        const completionEvent = new CustomEvent('analysisStateChange', {
          detail: { 
            isAnalyzing: false,
            ordersCount: newOrders.length,
            tokenId: result.tokenId
          }
        });
        window.dispatchEvent(completionEvent);
      }
      
    } catch (error) {
      console.error("Error al analizar el mensaje:", error);
      
      let errorTitle = "Error de análisis";
      let errorMessage = "Error al analizar el mensaje";
      
      if (error instanceof GeminiError) {
        if (error.status) {
          errorMessage = `Error HTTP ${error.status}: ${error.message}`;
        } else if (error.apiResponse) {
          errorMessage = `Error en la respuesta de la API: ${error.message}`;
        } else {
          errorMessage = error.message;
        }
        
        setPhase1Response(error.phase1Response || null);
        setPhase2Response(error.rawJsonResponse || null);
        
        // Si tenemos un tokenId, lo mantenemos para rastrear
        if (error.tokenId) {
          setTokenId(error.tokenId);
        }
      } else {
        errorMessage = (error as Error).message || "Error desconocido al analizar el mensaje";
      }
      
      setAnalysisError(errorMessage);
      setAlertMessage({
        title: errorTitle,
        message: errorMessage
      });
    } finally {
      // Notificamos que el análisis ha terminado con el tokenId actual
      window.dispatchEvent(new CustomEvent('analysisStateChange', {
        detail: { 
          isAnalyzing: false,
          tokenId: tokenId
        }
      }));
      
      setTimeout(() => {
        setIsAnalyzing(false);
        setProgress(0);
        setProgressStage("");
      }, 1000);
    }
  };

  const handleUpdateOrder = (index: number, updatedOrder: OrderCardType) => {
    const updatedOrders = [...orders];
    updatedOrders[index] = updatedOrder;
    setOrders(updatedOrders);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setMessage(text);
    } catch (err) {
      setAlertMessage({
        title: "Error de acceso",
        message: "No se pudo acceder al portapapeles"
      });
    }
  };

  const handleSaveOrder = async (orderIndex: number, order: OrderCardType) => {
    try {
      console.log('Intentando guardar el pedido:', order);
      
      if (!order.client.id) {
        toast({
          title: "Error al guardar",
          description: "El cliente no está identificado correctamente",
          variant: "destructive"
        });
        return false;
      }

      const clientId = order.client.id;
      
      let hasInvalidItems = false;
      let total = 0;
      
      for (const item of order.items) {
        if (!item.product.id) {
          hasInvalidItems = true;
          break;
        }
        
        const itemPrice = item.variant?.price || products.find(p => p.id === item.product.id)?.price || 0;
        total += item.quantity * itemPrice;
      }
      
      if (hasInvalidItems) {
        toast({
          title: "Error al guardar",
          description: "Hay productos no identificados correctamente",
          variant: "destructive"
        });
        return false;
      }

      const metadata = order.pickupLocation ? { pickupLocation: order.pickupLocation } : undefined;

      const { data: newOrder, error: orderError } = await supabase
        .from('orders')
        .insert([
          {
            client_id: clientId,
            date: new Date().toISOString().split('T')[0],
            status: 'pending',
            total: total,
            amount_paid: order.isPaid ? total : 0,
            balance: order.isPaid ? 0 : total,
            metadata: metadata
          }
        ])
        .select('id')
        .single();

      if (orderError) {
        console.error("Error al crear pedido:", orderError);
        throw new Error(`Error al crear pedido: ${orderError.message}`);
      }

      if (!newOrder || !newOrder.id) {
        throw new Error("No se pudo obtener el ID del pedido creado");
      }

      const orderItems = order.items.map(item => {
        const productPrice = products.find(p => p.id === item.product.id)?.price || 0;
        const variantPrice = item.variant?.id ? 
          products.find(p => p.id === item.product.id)?.variants?.find(v => v.id === item.variant?.id)?.price || 0 : 0;
        
        const price = variantPrice > 0 ? variantPrice : productPrice;
        
        return {
          order_id: newOrder.id,
          product_id: item.product.id!,
          variant_id: item.variant?.id || null,
          quantity: item.quantity,
          price: price,
          total: item.quantity * price
        };
      });

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

      if (itemsError) {
        console.error("Error al crear items del pedido:", itemsError);
        
        await supabase.from('orders').delete().eq('id', newOrder.id);
        
        throw new Error(`Error al crear items del pedido: ${itemsError.message}`);
      }

      const updatedOrders = [...orders];
      updatedOrders[orderIndex] = {
        ...order,
        id: newOrder.id,
        status: 'saved'
      };
      setOrders(updatedOrders);
      
      toast({
        title: "Pedido guardado",
        description: `El pedido de ${order.client.name} ha sido guardado correctamente`,
        variant: "success"
      });
      
      return true;
    } catch (error: any) {
      console.error("Error al guardar el pedido:", error);
      
      toast({
        title: "Error al guardar",
        description: error.message || "Error al guardar el pedido",
        variant: "destructive"
      });
      
      return false;
    }
  };

  const handleSaveAllOrders = async () => {
    setIsSavingAllOrders(true);
    
    try {
      const validOrders = orders.filter(order => 
        order.status !== 'saved' && 
        !order.items.some(item => item.status === 'duda') && 
        order.client.matchConfidence === 'alto' &&
        order.client.id && 
        order.items.every(item => item.product.id && item.quantity)
      );
      
      if (validOrders.length === 0) {
        setAlertMessage({
          title: "No hay pedidos para guardar",
          message: "No hay pedidos listos para guardar. Asegúrate de resolver todas las dudas pendientes."
        });
        return;
      }
      
      let successCount = 0;
      let errorCount = 0;
      
      for (let i = 0; i < validOrders.length; i++) {
        const orderIndex = orders.findIndex(o => o === validOrders[i]);
        if (orderIndex >= 0) {
          setProgressStage(`Guardando pedido ${i + 1} de ${validOrders.length}...`);
          setProgress(Math.round((i / validOrders.length) * 100));
          
          const success = await handleSaveOrder(orderIndex, validOrders[i]);
          if (success) {
            successCount++;
          } else {
            errorCount++;
          }
        }
      }
      
      setProgress(100);
      setProgressStage(`¡Pedidos guardados!`);
      
      if (successCount > 0) {
        setAlertMessage({
          title: "Pedidos guardados",
          message: `Se ${successCount === 1 ? 'ha' : 'han'} guardado ${successCount} pedido${successCount === 1 ? '' : 's'} correctamente${errorCount > 0 ? ` (${errorCount} con errores)` : ''}`
        });
        
        // Verificar si el análisis sigue en curso antes de limpiar los datos
        if (!isAnalyzing) {
          // Limpiar todos los datos relacionados con este análisis solo si no hay análisis en curso
          resetMagicOrderData();
        }
        
        // Actualizar el estado del análisis si tenemos un token
        if (tokenId) {
          await updateAnalysisStatus(tokenId, 'completed', {
            progress: 100,
            stage: 'Pedidos guardados',
            completed_at: new Date().toISOString()
          });
        }
      } else if (errorCount > 0) {
        setAlertMessage({
          title: "Error al guardar pedidos",
          message: `No se pudo guardar ningún pedido. Revisa los errores e intenta nuevamente.`
        });
      }
    } catch (error) {
      console.error("Error al guardar todos los pedidos:", error);
      setAlertMessage({
        title: "Error",
        message: "Ocurrió un error al intentar guardar los pedidos"
      });
    } finally {
      setTimeout(() => {
        setIsSavingAllOrders(false);
        setProgress(0);
        setProgressStage("");
      }, 1000);
    }
  };

  // Función para limpiar todos los datos relacionados con este análisis
  const resetMagicOrderData = () => {
    setOrders([]);
    setPhase1Response(null);
    setPhase2Response(null);
    setPhase3Response(null);
    setAnalysisId(null);
    setTokenId(null);
    
    localStorage.removeItem('magicOrder_orders');
    localStorage.removeItem('magicOrder_phase1Response');
    localStorage.removeItem('magicOrder_phase2Response');
    localStorage.removeItem('magicOrder_phase3Response');
    
    sessionStorage.removeItem('aiStatus');
    sessionStorage.removeItem('aiMessage');
    sessionStorage.removeItem('aiDetailedInfo');
    sessionStorage.removeItem('aiTokenId');
    
    // Notificar a otros componentes que el análisis ha terminado
    const event = new CustomEvent('analysisStateChange', {
      detail: { 
        isAnalyzing: false
      }
    });
    window.dispatchEvent(event);
  };

  const handleConfirmDeleteOrder = () => {
    if (orderToDelete !== null) {
      const updatedOrders = [...orders];
      updatedOrders.splice(orderToDelete.index, 1);
      setOrders(updatedOrders);
      setOrderToDelete(null);
      
      toast({
        title: "Pedido eliminado",
        description: `El pedido de ${orderToDelete.name} ha sido eliminado`,
        variant: "default"
      });
    }
  };

  const handleDeleteOrder = (index: number) => {
    const order = orders[index];
    setOrderToDelete({
      index, 
      name: order.client.name
    });
  };

  const handleResetAllOrders = () => {
    resetMagicOrderData();
    
    toast({
      title: "Pedidos reiniciados",
      description: "Se han eliminado todos los pedidos en proceso",
      variant: "default"
    });
  };

  const allOrdersComplete = orders.length > 0 && 
    orders.every(order => 
      order.client.id && 
      order.client.matchConfidence === 'alto' && 
      !order.items.some(item => item.status === 'duda' || !item.product.id || !item.quantity)
    );

  return (
    <AppLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
              <Wand className="h-7 w-7 text-primary" />
              Mensaje Mágico
            </h1>
            <p className="text-muted-foreground">
              Analiza mensajes de clientes y crea pedidos automáticamente
            </p>
          </div>
          
          <div className="flex gap-2">
            {(phase1Response || phase2Response || phase3Response) && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowAnalysisDialog(true)}
                className="flex items-center gap-1"
              >
                <FileText size={16} />
                Ver análisis en detalle
              </Button>
            )}
            
            {orders.length > 0 && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleResetAllOrders}
                className="flex items-center gap-1"
              >
                <RefreshCcw size={16} />
                Reiniciar pedidos mágicos
              </Button>
            )}
          </div>
        </div>

        {/* Componente de configuración de IA */}
        <AIConfigCard 
          apiProvider={apiProvider}
          geminiModel={geminiModel}
          analysisTime={analysisTime}
        />

        {/* Componente de entrada de mensaje */}
        <MessageInputCard 
          message={message}
          setMessage={setMessage}
          isAnalyzing={isAnalyzing}
          isLoadingData={isLoadingData}
          progress={progress}
          progressStage={progressStage}
          handleAnalyzeMessage={handleAnalyzeMessage}
          handlePaste={handlePaste}
          products={products}
          clients={clients}
        />

        {/* Componente de resultados */}
        <OrdersResultSection
          orders={orders}
          showOrderSummary={showOrderSummary}
          setShowOrderSummary={setShowOrderSummary}
          handleSaveAllOrders={handleSaveAllOrders}
          handleUpdateOrder={handleUpdateOrder}
          handleSaveOrder={handleSaveOrder}
          handleDeleteOrder={handleDeleteOrder}
          handleResetAllOrders={handleResetAllOrders}
          products={products}
          clients={clients}
          isSavingAllOrders={isSavingAllOrders}
          allOrdersComplete={allOrdersComplete}
          isCheckingPendingAnalysis={isCheckingPendingAnalysis}
        />
        
        {/* Diálogo para ver detalles del análisis */}
        <AnalysisDialog
          open={showAnalysisDialog}
          onOpenChange={setShowAnalysisDialog}
          phase1Response={phase1Response}
          phase2Response={phase2Response}
          phase3Response={phase3Response}
        />
        
        {/* Diálogos de alerta y confirmación */}
        <AlertMessage 
          alertMessage={alertMessage} 
          setAlertMessage={setAlertMessage} 
        />
        
        <DeleteOrderDialog
          orderToDelete={orderToDelete}
          setOrderToDelete={setOrderToDelete}
          handleConfirmDeleteOrder={handleConfirmDeleteOrder}
        />
      </div>
    </AppLayout>
  );
};

export default MagicOrder;
